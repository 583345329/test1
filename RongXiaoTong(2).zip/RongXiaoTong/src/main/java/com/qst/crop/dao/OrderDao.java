package com.qst.crop.dao;

import com.github.pagehelper.PageInfo;
import com.qst.crop.entity.Order;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderDao {
    List<Order> selectAll();

    List<Order> selectByExample(Order order);

    List<Order> selectByKeys(Order order);

    Order selectByPrimaryKey(Integer id);

    void insertSelective(Order order);

    void updateByPrimaryKeySelective(Order order);

    void deleteByPrimaryKey(Integer id);

    List<Order> selectAllNeeds(Order order);
}
