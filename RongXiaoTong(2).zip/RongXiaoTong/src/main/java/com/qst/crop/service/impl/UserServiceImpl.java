package com.qst.crop.service.impl;


import com.qst.crop.dao.UserDao;

import com.qst.crop.entity.User;
import com.qst.crop.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;



    @Override
    public User selectByUserName(String userName) {
        User user = userDao.selectByPrimaryKey(userName);
//        System.out.println("====================================loadUserByUsername访问了数据库===================================");
        return user;
    }


}
