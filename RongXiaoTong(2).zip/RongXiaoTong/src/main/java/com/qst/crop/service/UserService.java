package com.qst.crop.service;

import com.qst.crop.entity.User;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface UserService {


    User selectByUserName(String userName);

}
